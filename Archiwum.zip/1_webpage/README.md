### BASE WEBPAGE ###

1. Stwórz stronę www z trzema ścieżkami
   - ```/``` – Strona główna
   - ```/about-me``` – O mnie
   - ```/contact``` – Kontakt z formularze kontatkowym